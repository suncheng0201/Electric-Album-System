package upload;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
 
@SuppressWarnings("serial")
public class ad_loginServlet<ActionContext> extends HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        this.doGet(request,response);       
        
    }
 
    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
    	
    	System.out.println("后台服务开始…………");  
    	response.setContentType("text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("utf-8");
        
        PrintWriter out = response.getWriter(); 
        
        String nameId = (String) request.getParameter("nameId");          //从前端获取数据first
        String password = (String) request.getParameter("password");         //从前端获取数据second
        
        

       //String nameId = "9001";
       //String password = "1234";
        
        System.out.println("nameId:"+nameId);                                      //用于测试 ，判断是否成功获取到数据；
        System.out.println("password:"+password);   

        //匹配             
        ResultSet rs = null;
    	Statement stmt = null;
    	Connection conn = null;
    	PreparedStatement pstmt = null;
    	Boolean result=false;
    	
        try {
    		/* 加载并注册SQL Server的JDBC驱动	 */
    		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
    		/* 建立到SQL Server数据库的连接  */
    		String driverName="com.microsoft.sqlserver.jdbc.SQLServerDriver"; 
    		String dbURL="jdbc:sqlserver://localhost:1433;DatabaseName=照片管理系统"; 
    		String userName="sa"; 
    		String userPwd="123456";  
    		Class.forName(driverName);   //jdk版本6.0以上可以省略这句话 
		    conn=DriverManager.getConnection(dbURL,userName,userPwd); 
 
    		/* 访问数据库，执行SQL语句 */
    		 stmt = conn.createStatement();	

    		 rs = stmt.executeQuery("select password from dbo.administrator where ID="+nameId); 
    		 rs.next();
    		 String pass=rs.getString("password");
    		 //System.out.println(pass);
    		 pass = pass.replace(" ", "");
    		 result=pass.equals(password);

    	}
    	 catch (ClassNotFoundException e) {
    				e.printStackTrace();
    				out.println("管理员"+nameId+"登录失败           ");
    	        	out.print("3秒后跳转");
    	        	response.setHeader("Refresh","3;URL=login_ad.jsp"); 
    			} catch (SQLException e) {
    				e.printStackTrace();
    				out.println("管理员"+nameId+"登录失败           ");
    	        	out.print("3秒后跳转");
    	        	response.setHeader("Refresh","3;URL=login_ad.jsp"); 
    			} finally {
    				try {
    					if(rs != null) {
    						rs.close();						// 关闭ResultSet对象
    						rs = null;
    					}
    					if (pstmt != null) {
    						pstmt.close();					// 关闭PreparedStatement对象
    						pstmt = null;
    					}
    					if(stmt != null) {
    						stmt.close();					// 关闭Statement对象
    						stmt = null;
    					}
    					if (conn != null) {
    						conn.close();					// 关闭Connection对象
    						conn = null;
    					}
    				} catch (SQLException e) {
    					e.printStackTrace();
    					out.println("管理员"+nameId+"登录失败           ");
    		        	out.print("3秒后跳转");
    		        	response.setHeader("Refresh","3;URL=login_ad.jsp"); 
    				}
    			}
        

        if(result)
        {
            out.println("管理员"+nameId+"登录成功           ");
            out.print("3秒后跳转");
            System.out.print("管理"+nameId+"登录成功\n3秒后跳转");           
            response.setHeader("Refresh","3;URL=operation_ad.jsp?nameId="+nameId); 
            
        }
        else
        {
        	out.println("管理员"+nameId+"登录失败           ");
        	out.print("3秒后跳转");
        	response.setHeader("Refresh","3;URL=login_ad.jsp"); 
        }
        
        
        /* 
         * 链接数据库 
         * */
        
    }
}





