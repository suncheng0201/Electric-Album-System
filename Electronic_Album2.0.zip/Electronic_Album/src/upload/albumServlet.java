package upload;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServlet;

	@SuppressWarnings("serial")
	public class albumServlet<ActionContext> extends HttpServlet {
	    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
	        this.doGet(request,response);       
	    }

	    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
	    	
	    	System.out.println("后台服务开始…………");  
	    	response.setContentType("text/html;charset=UTF-8");
	        response.setCharacterEncoding("UTF-8");
	        request.setCharacterEncoding("utf-8");
	        
	        PrintWriter out = response.getWriter(); 
	        
	        String nameId = (String) request.getParameter("nameId");          //从前端获取数据first
	        String user_name = (String) request.getParameter("user_name");          //从前端获取数据first
	        
	        String album_type = (String) request.getParameter("album_type");          //从前端获取数据first
	        String album_add = (String) request.getParameter("album_add"); 
	        String album_old = (String) request.getParameter("album_old"); 
	        String album_modify = (String) request.getParameter("album_modify"); 
	        String album_delete = (String) request.getParameter("album_delete");
	        String type_new = (String) request.getParameter("type_new");
	        
	        String flag = (String) request.getParameter("flag"); 
	       //String nameId = "9001";
	       //String password = "1234";
	        
	        System.out.println("flag:"+flag);                                      //用于测试 ，判断是否成功获取到数据；

	        //匹配             
	        ResultSet rs = null;
	    	Statement stmt = null;
	    	Connection conn = null;
	    	PreparedStatement pstmt = null;
	    	Boolean result=false;
	    	
	        try {
	    		/* 加载并注册SQL Server的JDBC驱动	 */
	    		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	    		/* 建立到SQL Server数据库的连接  */
	    		String driverName="com.microsoft.sqlserver.jdbc.SQLServerDriver"; 
	    		String dbURL="jdbc:sqlserver://localhost:1433;DatabaseName=照片管理系统"; 
	    		String userName="sa"; 
	    		String userPwd="123456";  
	    		Class.forName(driverName);   //jdk版本6.0以上可以省略这句话 
			    conn=DriverManager.getConnection(dbURL,userName,userPwd); 
	 
	    		/* 访问数据库，执行SQL语句 */
	    		 stmt = conn.createStatement();	
	    		 
	    		 if(flag.compareTo("1") == 0)
	    		 {
	    			 
	    		 /*增加TP*/
	    			 PreparedStatement preparedStatement = conn.prepareStatement("insert into album (ID,album_name,type)values('"+nameId+"','"+album_add+"','"+album_type+"')");      
	    			 preparedStatement.executeUpdate();
	    			 preparedStatement.close();
	    		 }
	    		 else if(flag.compareTo("2")==0)
	    		 {
	    			 
	             /*修改TP*/
	    	     PreparedStatement preparedStatement = conn.prepareStatement("update photo set album_name ='"+album_modify+"' where (ID ='"+nameId+"' and album_name='"+album_old+"')");
	             preparedStatement.executeUpdate();                   //modify与old定义反了
	             System.out.println(album_modify+" "+album_old);
	             preparedStatement = conn.prepareStatement("update album set album_name ='"+album_modify+"' where (ID ='"+nameId+"' and album_name='"+album_old+"')");
	             preparedStatement.executeUpdate();
	             preparedStatement.close();
	             
	    		 }
	    		 else if(flag.compareTo("3")==0)
	    		 {
	    			 
	             /*删除TP*/
	    		 PreparedStatement preparedStatement = conn.prepareStatement("Delete from album where album_name = '"+album_delete+"'");
	             preparedStatement.executeUpdate();
	             
	             preparedStatement = conn.prepareStatement("Delete from photo where album_name = '"+album_delete+"'and id='"+nameId+"'");
	             preparedStatement.executeUpdate();
	             preparedStatement.close();
	    		 }
	    		 else if(flag.compareTo("4")==0)
	    		 {
	    			 /*修改TP*/
		             PreparedStatement preparedStatement = conn.prepareStatement("update album set type ='"+type_new+"' where (ID ='"+nameId+"' and album_name='"+album_old+"')");
		             preparedStatement.executeUpdate();
		             preparedStatement.close();
	    		 }
	             

	    	}
	    	 catch (ClassNotFoundException e) {
	    				e.printStackTrace();
	    			} catch (SQLException e) {
	    				e.printStackTrace();
	    			} finally {
	    				try {
	    					if(rs != null) {
	    						rs.close();						// 关闭ResultSet对象
	    						rs = null;
	    					}
	    					if (pstmt != null) {
	    						pstmt.close();					// 关闭PreparedStatement对象
	    						pstmt = null;
	    					}
	    					if(stmt != null) {
	    						stmt.close();					// 关闭Statement对象
	    						stmt = null;
	    					}
	    					if (conn != null) {
	    						conn.close();					// 关闭Connection对象
	    						conn = null;
	    					}
	    				} catch (SQLException e) {
	    					e.printStackTrace();
	    				}
	    			}
	        
	        
	        /* 
	         * 链接数据库 
	         * */
	        
	    }
	}

