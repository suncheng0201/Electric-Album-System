package upload;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
 
@SuppressWarnings("serial")
public class findkeyServlet<ActionContext> extends HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        this.doGet(request,response);       
        
    }
 
    @SuppressWarnings("resource")
	protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
    	
    	System.out.println("后台服务开始…………");  
    	response.setContentType("text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("utf-8");
        
        PrintWriter out = response.getWriter();  
        
 
     
        String user_ID = (String) request.getParameter("user_ID");          //从前端获取数据first
        String userpsd = (String) request.getParameter("userpsd");         //从前端获取数据second
        String s_question = (String) request.getParameter("s_question");          //从前端获取数据first
        String s_answer = (String) request.getParameter("s_answer");         //从前端获取数据second
       // String user_name = 
       // String user_name = "9001";
       // String password = "123";
        
        System.out.println("user_ID:"+user_ID);                                      //用于测试 ，判断是否成功获取到数据；
        System.out.println("userpsd:"+userpsd);   
        System.out.println("s_question:"+s_question);                                      //用于测试 ，判断是否成功获取到数据；
        System.out.println("s_answer:"+s_answer); 
        //匹配
        
        ResultSet rs = null;
    	Statement stmt = null;
    	Connection conn = null;
    	PreparedStatement pstmt = null;
    	Boolean result=false;
    	
        try {
    		/* 加载并注册SQL Server的JDBC驱动	 */
        	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
    		/* 建立到SQL Server数据库的连接  */
    		String driverName="com.microsoft.sqlserver.jdbc.SQLServerDriver"; 
    		String dbURL="jdbc:sqlserver://localhost:1433;DatabaseName=照片管理系统"; 
    		String userName="sa"; 
    		String userPwd="123456";  
    		Class.forName(driverName);   //jdk版本6.0以上可以省略这句话 
    		conn=DriverManager.getConnection(dbURL,userName,userPwd); 

    		 stmt = conn.createStatement();	
    		 rs = stmt.executeQuery("select s_question from dbo.account where ID="+user_ID); 
    		 rs.next();
    		 String sq=rs.getString("s_question");
    		 rs = stmt.executeQuery("select s_answer from dbo.account where ID="+user_ID); 
    		 rs.next();
    		 String sa=rs.getString("s_answer");
    		 sa=sa.replaceAll(" ","");
    		 sq=sq.replaceAll(" ","");
    		 Boolean b=sq.equals(s_question)&&sa.equals(s_answer);
    		 
    		 if(b)
    		 {
    			 stmt.executeUpdate("update dbo.account set password='"+userpsd+"'where ID="+user_ID);
    			 rs = stmt.executeQuery("select user_name from dbo.account where ID="+user_ID); 
        		 rs.next();
        		 String user_name=rs.getString("user_name");
        		 user_name = user_name.replace(" ","");
    			 
    			 out.println("用户"+user_ID+"更改密码成功           ");
    	            out.print("3秒后跳转");
    	            System.out.print("用户"+user_ID+"更改密码成功\n3秒后跳转");           
    	            response.setHeader("Refresh","3;URL=downalbum.jsp?user_name="+user_name+"&nameId="+user_ID); 
    		 }
    		 else
    		 {
    			 out.println("用户"+user_ID+"更改密码失败           ");
    	        	out.print("3秒后跳转");
    	        	System.out.print("用户"+user_ID+"更改密码失败\n3秒后跳转");
    	        	response.setHeader("Refresh","3;URL=findkey.jsp"); 
    		 }
    	}
    	 catch (ClassNotFoundException e) {
    				e.printStackTrace();
    				out.println("用户"+user_ID+"更改密码失败           ");
    	        	out.print("3秒后跳转");
    	        	System.out.print("用户"+user_ID+"更改密码失败\n3秒后跳转");
    	        	response.setHeader("Refresh","3;URL=findkey.jsp"); 
    			} catch (SQLException e) {
    				e.printStackTrace();
    				out.println("用户"+user_ID+"更改密码失败           ");
    	        	out.print("3秒后跳转");
    	        	System.out.print("用户"+user_ID+"更改密码失败\n3秒后跳转");
    	        	response.setHeader("Refresh","3;URL=findkey.jsp"); 
    			} finally {
    				try {
    					if(rs != null) {
    						rs.close();						// 关闭ResultSet对象
    						rs = null;
    					}
    					if (pstmt != null) {
    						pstmt.close();					// 关闭PreparedStatement对象
    						pstmt = null;
    					}
    					if(stmt != null) {
    						stmt.close();					// 关闭Statement对象
    						stmt = null;
    					}
    					if (conn != null) {
    						conn.close();					// 关闭Connection对象
    						conn = null;
    					}
    				} catch (SQLException e) {
    					e.printStackTrace();
    					out.println("用户"+user_ID+"更改密码失败           ");
        	        	out.print("3秒后跳转");
        	        	System.out.print("用户"+user_ID+"更改密码失败\n3秒后跳转");
        	        	response.setHeader("Refresh","3;URL=findkey.jsp"); 
    					
    				}
    			}
/*
        if(true)
        {
            out.println("用户"+user_name+"登录成功           ");
            out.print("3秒后跳转");
            System.out.print("用户"+user_name+"登录成功\n3秒后跳转");           
            response.setHeader("Refresh","3;URL=operation.jsp"); 
            
        }
        else
        {
        	out.println("用户"+user_name+"登录失败           ");
        	out.print("3秒后跳转");
        	System.out.print("用户"+user_name+"登录失败\n3秒后跳转");
        	response.setHeader("Refresh","3;URL=login.jsp"); 
        }
        */
        
        /* 
         * 链接数据库 
         * */
        
    }
}





