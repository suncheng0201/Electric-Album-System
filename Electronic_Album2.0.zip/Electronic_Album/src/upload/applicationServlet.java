package upload;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
 
@SuppressWarnings("serial")
public class applicationServlet<ActionContext> extends HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        this.doGet(request,response);       
        
    }
 
    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
    	
    	System.out.println("后台服务开始…………");  
    	response.setContentType("text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("utf-8");
        
        PrintWriter out = response.getWriter(); 
        
        String nameId = (String) request.getParameter("nameId");          
        String password = (String) request.getParameter("password");         
        String friend_id = (String) request.getParameter("friend_id");
        String user_name = (String) request.getParameter("user_name");
        String flag = (String) request.getParameter("flag");
        String agree_friend = (String) request.getParameter("agree_friend");
        String disagree_friend = (String) request.getParameter("disagree_friend");
        String friend_delete = (String) request.getParameter("friend_delete");
       //String nameId = "9001";
       //String password = "1234";
        

        //匹配             
        ResultSet rs = null;
    	Statement stmt = null;
    	Connection conn = null;
    	PreparedStatement pstmt = null;
    	Boolean result=false;
    	
        try {
    		/* 加载并注册SQL Server的JDBC驱动	 */
    		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
    		/* 建立到SQL Server数据库的连接  */
    		String driverName="com.microsoft.sqlserver.jdbc.SQLServerDriver"; 
    		String dbURL="jdbc:sqlserver://localhost:1433;DatabaseName=照片管理系统"; 
    		String userName="sa"; 
    		String userPwd="123456";  
    		Class.forName(driverName);   //jdk版本6.0以上可以省略这句话 
		    conn=DriverManager.getConnection(dbURL,userName,userPwd); 
 
    		/* 访问数据库，执行SQL语句 */
			 stmt = conn.createStatement();	
			 if(flag.compareTo("1")==0)
			 {
				 rs = stmt.executeQuery("Select * from dbo.account where id="+nameId); 
				 if(rs.next())
				 {
				 	PreparedStatement preparedStatement = conn.prepareStatement("insert into application(id,friend) values ('"+nameId+"','"+friend_id+"')");
					preparedStatement.executeUpdate();
				    preparedStatement.close();
				    
				    out.print("申请成功");
				    response.setHeader("Refresh","1;URL=downalbum.jsp?nameId="+nameId+"&user_name="+user_name); 
				 }
				 else
				 {
					 out.print("申请失败，用户不存在");
					 //用户不存在
					 response.setHeader("Refresh","1;URL=downalbum.jsp?nameId="+nameId+"&user_name="+user_name); 

				 }
			 }
			 else if(flag.compareTo("2")==0)
			 {
				 PreparedStatement preparedStatement = conn.prepareStatement("insert into friend(id,friend_id) values ('"+nameId+"','"+agree_friend+"')");
					preparedStatement.executeUpdate();
					preparedStatement = conn.prepareStatement("insert into friend(id,friend_id) values ('"+agree_friend+"','"+nameId+"')");
					preparedStatement.executeUpdate();
					preparedStatement = conn.prepareStatement("delete from application where id='"+agree_friend+"' and friend='"+nameId+"'");
					preparedStatement.executeUpdate();
					preparedStatement = conn.prepareStatement("delete from application where id='"+nameId+"' and friend='"+agree_friend+"'");
					preparedStatement.executeUpdate();
					preparedStatement.close();
					out.print("好友添加成功！");
					response.setHeader("Refresh","1;URL=downalbum.jsp?nameId="+nameId+"&user_name="+user_name); 
			 }
			 else if(flag.compareTo("3")==0)
			 {
				 PreparedStatement preparedStatement = conn.prepareStatement("delete from application where id='"+disagree_friend+"' and friend='"+nameId+"'");
					preparedStatement.executeUpdate();
				    preparedStatement.close();
				    out.print("已拒绝好友申请！");
				    response.setHeader("Refresh","1;URL=downalbum.jsp?nameId="+nameId+"&user_name="+user_name); 
			 }
			 else if(flag.compareTo("4")==0)
			 {
				 PreparedStatement preparedStatement = conn.prepareStatement("delete from friend where id='"+nameId+"' and friend_id='"+friend_delete+"'");
				 preparedStatement.executeUpdate();
				 preparedStatement = conn.prepareStatement("delete from friend where id='"+friend_delete+"' and friend_id='"+nameId+"'");
				 preparedStatement.executeUpdate();
				 preparedStatement.close();
				 
				 out.print("好友删除成功！");
				 response.setHeader("Refresh","1;URL=downalbum.jsp?nameId="+nameId+"&user_name="+user_name); 
			 }

        
        
        /* 
         * 链接数据库 
         * */
        
		    }catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if(rs != null) {
						rs.close();						// 关闭ResultSet对象
						rs = null;
					}
					if (pstmt != null) {
						pstmt.close();					// 关闭PreparedStatement对象
						pstmt = null;
					}
					if(stmt != null) {
						stmt.close();					// 关闭Statement对象
						stmt = null;
					}
					if (conn != null) {
						conn.close();					// 关闭Connection对象
						conn = null;
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

        
    }
}





