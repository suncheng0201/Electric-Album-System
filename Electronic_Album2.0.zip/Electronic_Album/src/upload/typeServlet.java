package upload;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServlet;

	@SuppressWarnings("serial")
	public class typeServlet<ActionContext> extends HttpServlet {
	    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
	        this.doGet(request,response);       
	    }
	 
	    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
	    	
	    	System.out.println("后台服务开始…………");  
	    	response.setContentType("text/html;charset=UTF-8");
	        response.setCharacterEncoding("UTF-8");
	        request.setCharacterEncoding("utf-8");
	        
	        PrintWriter out = response.getWriter(); 
	        
	        String old_type = (String) request.getParameter("old_type");          //从前端获取数据first
	        String new_type = (String) request.getParameter("new_type"); 
	        String flag = (String) request.getParameter("flag"); 
	       //String nameId = "9001";
	       //String password = "1234";
	        
	        System.out.println("flag:"+flag);                                      //用于测试 ，判断是否成功获取到数据；

	        //匹配             
	        ResultSet rs = null;
	    	Statement stmt = null;
	    	Connection conn = null;
	    	PreparedStatement pstmt = null;
	    	Boolean result=false;
	    	
	        try {
	    		/* 加载并注册SQL Server的JDBC驱动	 */
	    		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	    		/* 建立到SQL Server数据库的连接  */
	    		String driverName="com.microsoft.sqlserver.jdbc.SQLServerDriver"; 
	    		String dbURL="jdbc:sqlserver://localhost:1433;DatabaseName=照片管理系统"; 
	    		String userName="sa"; 
	    		String userPwd="123456";  
	    		Class.forName(driverName);   //jdk版本6.0以上可以省略这句话 
			    conn=DriverManager.getConnection(dbURL,userName,userPwd); 
	 
	    		/* 访问数据库，执行SQL语句 */
	    		 stmt = conn.createStatement();	
	    		 
	    		 if(flag.compareTo("1") == 0)
	    		 {
	    			 
	    		 /*增加TP*/
	    		 PreparedStatement preparedStatement = conn.prepareStatement("Insert into dbo.type(type) values ('"+old_type+"')");
	             preparedStatement.executeUpdate();
	             preparedStatement.close();
	    		 }
	    		 else if(flag.compareTo("2")==0)
	    		 {
	    			 
	             /*修改TP*/
	    		 PreparedStatement preparedStatement = conn.prepareStatement("Update dbo.type set type='"+new_type+"' where type ='"+old_type+"'");
	             preparedStatement.executeUpdate();
	             
	             preparedStatement = conn.prepareStatement("Update dbo.album set type='"+new_type+"' where type ='"+old_type+"'");
	             preparedStatement.executeUpdate();
	             preparedStatement.close();
	             
	    		 }
	    		 else if(flag.compareTo("3")==0)
	    		 {
	    			 
	             /*删除TP*/
	             PreparedStatement preparedStatement = conn.prepareStatement("Delete from dbo.type where type = '"+old_type+"'");
	             preparedStatement.executeUpdate();
	             
	             preparedStatement = conn.prepareStatement("Update dbo.album set type='normal' where type ='"+old_type+"'");
	             preparedStatement.executeUpdate();
	             preparedStatement.close();
	    		 }
	             

	    	}
	    	 catch (ClassNotFoundException e) {
	    				e.printStackTrace();
	    			} catch (SQLException e) {
	    				e.printStackTrace();
	    			} finally {
	    				try {
	    					if(rs != null) {
	    						rs.close();						// 关闭ResultSet对象
	    						rs = null;
	    					}
	    					if (pstmt != null) {
	    						pstmt.close();					// 关闭PreparedStatement对象
	    						pstmt = null;
	    					}
	    					if(stmt != null) {
	    						stmt.close();					// 关闭Statement对象
	    						stmt = null;
	    					}
	    					if (conn != null) {
	    						conn.close();					// 关闭Connection对象
	    						conn = null;
	    					}
	    				} catch (SQLException e) {
	    					e.printStackTrace();
	    				}
	    			}
	        
	        
	        /* 
	         * 链接数据库 
	         * */
	        
	    }
	}

